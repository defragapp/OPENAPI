import { Agent, tool } from '@openai/agents';
import { z } from 'zod';
import type { Env } from '../env';
import { getBaselineSummary, getCurrentConditions } from '../adapters/sovv';

export interface SovereignContext {
  env: Env;
  accountId: string;
  threadId: string;
  traceId: string;
  covenantEnabled: boolean;
}

const baselineTool = tool({
  name: 'get_my_baseline_summary',
  description: 'Return a reduced plain-language Baseline summary for the authenticated user.',
  parameters: z.object({ personId: z.string(), focus: z.string().optional() }),
  execute: async ({ personId, focus }, context) => {
    const runtime = context?.context as SovereignContext;
    return getBaselineSummary(runtime.env, personId, focus);
  }
});

const currentConditionsTool = tool({
  name: 'get_my_current_conditions',
  description: 'Return reduced current-condition amplification. Never infer exact emotion.',
  parameters: z.object({ personId: z.string() }),
  execute: async ({ personId }, context) => {
    const runtime = context?.context as SovereignContext;
    return getCurrentConditions(runtime.env, personId);
  }
});

export const sovereignAgent = new Agent<SovereignContext>({
  name: 'Sovereign',
  instructions: `You are Sovereign, the single user-facing agent for Sovereign.OS.
Use plain, sharp, anti-stigma language.
Never diagnose, claim hidden intent, or present probabilities as facts.
Distinguish Baseline tendency, current amplification, observed behavior, and unknown actual state.
Do not require an incident before being useful.
Use only consented tool context.
Covenant is Christian and biblical, but it is unavailable unless covenantEnabled is true.
Keep what helps. Leave what doesn't.`,
  tools: [baselineTool, currentConditionsTool]
});
