import type { Env } from '../env';

export interface BaselineSummary {
  summary: string;
  dimensions: Array<{ name: string; tendency: string; underPressure?: string; supportiveMove?: string }>;
  unknowns: string[];
  sourceRefs: string[];
}

async function callSovv<T>(env: Env, path: string, payload: unknown): Promise<T> {
  const response = await fetch(new URL(path, env.SOVV_INTERNAL_BASE_URL), {
    method: 'POST',
    headers: {
      authorization: `Bearer ${env.SOVV_INTERNAL_AUTH_TOKEN}`,
      'content-type': 'application/json',
      'x-sovereign-contract-version': '1'
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) throw new Error(`SOVV adapter failed with ${response.status}`);
  return response.json<T>();
}

export function getBaselineSummary(env: Env, personId: string, focus?: string): Promise<BaselineSummary> {
  return callSovv(env, '/internal/baseline/summary', { personId, focus, includeFrameworkLabels: false });
}

export function getCurrentConditions(env: Env, personId: string): Promise<unknown> {
  return callSovv(env, '/internal/conditions/current', { personId, precision: 'reduced' });
}
