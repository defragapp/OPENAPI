export interface Env {
  APP_ENV: string;
  APP_VERSION: string;
  DB: D1Database;
  THREADS: DurableObjectNamespace;
  OPENAI_API_KEY: string;
  STRIPE_SECRET_KEY: string;
  STRIPE_WEBHOOK_SECRET: string;
  SOVV_INTERNAL_BASE_URL: string;
  SOVV_INTERNAL_AUTH_TOKEN: string;
}

export interface AuthContext {
  accountId: string;
  subject: string;
}
