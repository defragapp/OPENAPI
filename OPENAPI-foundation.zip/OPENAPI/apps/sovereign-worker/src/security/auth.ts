import type { AuthContext, Env } from '../env';

export async function requireAuth(request: Request, _env: Env): Promise<AuthContext> {
  const subject = request.headers.get('x-sovereign-subject');
  const accountId = request.headers.get('x-sovereign-account');
  if (!subject || !accountId) throw new Response('Unauthorized', { status: 401 });
  return { subject, accountId };
}

export function requireSameOrigin(request: Request): void {
  const origin = request.headers.get('origin');
  const url = new URL(request.url);
  if (origin && origin !== url.origin) throw new Response('Forbidden origin', { status: 403 });
}
