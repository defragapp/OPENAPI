import { Hono } from 'hono';
import type { Env } from './env';
import { ThreadCoordinator } from './durable/ThreadCoordinator';
import { requireAuth, requireSameOrigin } from './security/auth';
import { withSecurityHeaders } from './security/headers';
import { getEntitlements } from './db/entitlements';
import { handleStripeWebhook } from './routes/stripe';

const app = new Hono<{ Bindings: Env }>();

app.use('*', async (context, next) => {
  await next();
  context.res = withSecurityHeaders(context.res);
});

app.get('/healthz', async (context) => {
  const db = await context.env.DB.prepare('SELECT 1 AS ok').first<{ ok: number }>();
  return context.json({ ok: db?.ok === 1, version: context.env.APP_VERSION, environment: context.env.APP_ENV });
});

app.post('/api/v1/stripe/webhook', (context) => handleStripeWebhook(context.req.raw, context.env));

app.post('/api/v1/threads/:threadId/messages', async (context) => {
  requireSameOrigin(context.req.raw);
  const auth = await requireAuth(context.req.raw, context.env);
  const body = await context.req.json<{ message?: string; context?: unknown }>();
  const message = body.message?.trim();
  if (!message) return context.json({ error: 'Message required' }, 400);

  const idempotencyKey = context.req.header('x-idempotency-key');
  if (!idempotencyKey) return context.json({ error: 'Idempotency key required' }, 400);

  const entitlements = await getEntitlements(context.env, auth.accountId);
  const threadId = context.req.param('threadId');
  const coordinator = context.env.THREADS.get(context.env.THREADS.idFromName(threadId));
  const coordination = await coordinator.fetch('https://thread.internal/turn', {
    method: 'POST',
    body: JSON.stringify({ idempotencyKey, accountId: auth.accountId, message })
  });
  if (!coordination.ok) return coordination;
  const turn = await coordination.json<{ sequence: number; duplicate: boolean }>();

  // Agent streaming is connected after the SOVV contracts and auth source are configured.
  return context.json({
    message: 'The secure thread foundation is ready. Agent execution is waiting for live adapter bindings.',
    threadId,
    sequence: turn.sequence,
    duplicate: turn.duplicate,
    plan: entitlements.plan
  }, turn.duplicate ? 200 : 202);
});

app.notFound((context) => context.json({ error: 'Not found' }, 404));

export { ThreadCoordinator };
export default app;
